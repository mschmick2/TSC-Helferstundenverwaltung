<?php

declare(strict_types=1);

namespace Tests\Support;

/**
 * MailHog Test Helper
 * 
 * Ermöglicht das Prüfen von E-Mails in automatisierten Tests.
 * MailHog muss auf localhost:8025 laufen.
 * 
 * @example
 * ```php
 * $mailhog = new MailHogHelper();
 * $mailhog->deleteAllMessages(); // Vor dem Test leeren
 * 
 * // ... Code der E-Mail sendet ...
 * 
 * $messages = $mailhog->getMessages();
 * $this->assertCount(1, $messages);
 * $this->assertEmailContains($messages[0], 'Willkommen');
 * ```
 */
class MailHogHelper
{
    private string $apiUrl;
    private int $timeout;

    public function __construct(
        string $apiUrl = 'http://localhost:8025/api/v2',
        int $timeout = 5
    ) {
        $this->apiUrl = rtrim($apiUrl, '/');
        $this->timeout = $timeout;
    }

    /**
     * Prüft ob MailHog erreichbar ist
     */
    public function isAvailable(): bool
    {
        $ch = curl_init($this->apiUrl . '/messages?limit=1');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 2,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $httpCode === 200;
    }

    /**
     * Holt alle Nachrichten aus MailHog
     * 
     * @param int $limit Maximale Anzahl (Standard: 50)
     * @return array Array von Nachrichten
     */
    public function getMessages(int $limit = 50): array
    {
        $response = $this->request('GET', "/messages?limit={$limit}");
        return $response['items'] ?? [];
    }

    /**
     * Holt die neueste Nachricht
     */
    public function getLatestMessage(): ?array
    {
        $messages = $this->getMessages(1);
        return $messages[0] ?? null;
    }

    /**
     * Sucht Nachrichten nach Empfänger
     */
    public function getMessagesByRecipient(string $email): array
    {
        $messages = $this->getMessages(100);
        return array_filter($messages, function ($msg) use ($email) {
            foreach ($msg['Content']['Headers']['To'] ?? [] as $to) {
                if (stripos($to, $email) !== false) {
                    return true;
                }
            }
            return false;
        });
    }

    /**
     * Sucht Nachrichten nach Betreff
     */
    public function getMessagesBySubject(string $subjectContains): array
    {
        $messages = $this->getMessages(100);
        return array_filter($messages, function ($msg) use ($subjectContains) {
            $subject = $msg['Content']['Headers']['Subject'][0] ?? '';
            return stripos($subject, $subjectContains) !== false;
        });
    }

    /**
     * Löscht alle Nachrichten in MailHog
     */
    public function deleteAllMessages(): bool
    {
        $response = $this->request('DELETE', '/messages');
        return $response !== null;
    }

    /**
     * Löscht eine einzelne Nachricht
     */
    public function deleteMessage(string $messageId): bool
    {
        $response = $this->request('DELETE', "/messages/{$messageId}");
        return $response !== null;
    }

    /**
     * Wartet auf eine bestimmte Anzahl von Nachrichten
     * 
     * @param int $expectedCount Erwartete Anzahl
     * @param int $timeoutSeconds Maximale Wartezeit
     * @return bool True wenn Anzahl erreicht
     */
    public function waitForMessages(int $expectedCount, int $timeoutSeconds = 10): bool
    {
        $start = time();
        while (time() - $start < $timeoutSeconds) {
            $messages = $this->getMessages($expectedCount + 10);
            if (count($messages) >= $expectedCount) {
                return true;
            }
            usleep(250000); // 250ms warten
        }
        return false;
    }

    /**
     * Extrahiert den Body einer Nachricht (Text oder HTML)
     */
    public function getMessageBody(array $message, string $type = 'text'): string
    {
        if ($type === 'html') {
            // HTML-Body aus MIME-Parts extrahieren
            foreach ($message['MIME']['Parts'] ?? [] as $part) {
                $contentType = $part['Headers']['Content-Type'][0] ?? '';
                if (stripos($contentType, 'text/html') !== false) {
                    return $part['Body'] ?? '';
                }
            }
        }

        // Plain-Text Body
        return $message['Content']['Body'] ?? '';
    }

    /**
     * Extrahiert Links aus einer HTML-E-Mail
     */
    public function extractLinks(array $message): array
    {
        $html = $this->getMessageBody($message, 'html');
        preg_match_all('/href=["\']([^"\']+)["\']/', $html, $matches);
        return $matches[1] ?? [];
    }

    /**
     * Prüft ob E-Mail einen bestimmten Text enthält
     */
    public function messageContains(array $message, string $needle): bool
    {
        $body = $this->getMessageBody($message, 'text');
        $htmlBody = $this->getMessageBody($message, 'html');
        $subject = $message['Content']['Headers']['Subject'][0] ?? '';

        return stripos($body, $needle) !== false
            || stripos($htmlBody, $needle) !== false
            || stripos($subject, $needle) !== false;
    }

    /**
     * Gibt Details einer Nachricht formatiert aus (für Debugging)
     */
    public function dumpMessage(array $message): string
    {
        $headers = $message['Content']['Headers'] ?? [];
        $output = "=== E-Mail Details ===\n";
        $output .= "ID: " . ($message['ID'] ?? 'unknown') . "\n";
        $output .= "Von: " . ($headers['From'][0] ?? 'unknown') . "\n";
        $output .= "An: " . implode(', ', $headers['To'] ?? []) . "\n";
        $output .= "Betreff: " . ($headers['Subject'][0] ?? 'kein Betreff') . "\n";
        $output .= "Datum: " . ($headers['Date'][0] ?? 'unknown') . "\n";
        $output .= "Body:\n" . $this->getMessageBody($message, 'text') . "\n";
        $output .= "======================\n";
        return $output;
    }

    /**
     * HTTP-Request an MailHog API
     */
    private function request(string $method, string $endpoint): ?array
    {
        $ch = curl_init($this->apiUrl . $endpoint);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode >= 200 && $httpCode < 300) {
            return json_decode($response, true) ?? [];
        }

        return null;
    }
}
