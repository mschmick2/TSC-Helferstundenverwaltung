<?php

declare(strict_types=1);

namespace Tests\Integration\Email;

use PHPUnit\Framework\TestCase;
use Tests\Support\MailHogHelper;

/**
 * E-Mail Integration Tests
 * 
 * Diese Tests prüfen die E-Mail-Funktionalität gegen MailHog.
 * Voraussetzung: MailHog läuft auf localhost:8025
 * 
 * Ausführen mit:
 *   vendor/bin/phpunit --filter EmailTest
 */
class EmailTest extends TestCase
{
    private MailHogHelper $mailhog;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->mailhog = new MailHogHelper(
            getenv('MAILHOG_API_URL') ?: 'http://localhost:8025/api/v2'
        );

        // Prüfen ob MailHog erreichbar ist
        if (!$this->mailhog->isAvailable()) {
            $this->markTestSkipped('MailHog ist nicht erreichbar auf localhost:8025');
        }

        // Alle vorherigen E-Mails löschen für sauberen Teststart
        $this->mailhog->deleteAllMessages();
    }

    /**
     * Test: MailHog-Verbindung funktioniert
     */
    public function testMailHogIsAvailable(): void
    {
        $this->assertTrue(
            $this->mailhog->isAvailable(),
            'MailHog sollte auf localhost:8025 erreichbar sein'
        );
    }

    /**
     * Test: E-Mail kann gesendet und empfangen werden
     * 
     * Dieser Test sendet eine echte E-Mail über PHPMailer an MailHog
     * und prüft, ob sie angekommen ist.
     */
    public function testCanSendAndReceiveEmail(): void
    {
        // E-Mail über das System senden (hier Beispiel mit PHPMailer direkt)
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        
        try {
            // SMTP-Konfiguration für MailHog
            $mail->isSMTP();
            $mail->Host = getenv('MAIL_HOST') ?: 'localhost';
            $mail->Port = (int)(getenv('MAIL_PORT') ?: 1025);
            $mail->SMTPAuth = false;
            
            // Absender und Empfänger
            $mail->setFrom('system@vaes.local', 'VAES System');
            $mail->addAddress('test@example.com', 'Test User');
            
            // Inhalt
            $mail->Subject = 'VAES Testmail';
            $mail->Body = 'Dies ist eine Test-E-Mail vom automatisierten Test.';
            $mail->AltBody = 'Dies ist eine Test-E-Mail vom automatisierten Test.';
            
            $mail->send();
        } catch (\Exception $e) {
            $this->fail('E-Mail konnte nicht gesendet werden: ' . $e->getMessage());
        }

        // Kurz warten und dann prüfen
        $this->assertTrue(
            $this->mailhog->waitForMessages(1, 5),
            'E-Mail sollte innerhalb von 5 Sekunden ankommen'
        );

        // E-Mail-Inhalt prüfen
        $message = $this->mailhog->getLatestMessage();
        $this->assertNotNull($message, 'Es sollte eine E-Mail vorhanden sein');
        
        $this->assertTrue(
            $this->mailhog->messageContains($message, 'VAES Testmail'),
            'E-Mail sollte den Betreff enthalten'
        );
        
        $this->assertTrue(
            $this->mailhog->messageContains($message, 'Test-E-Mail'),
            'E-Mail sollte den Body-Text enthalten'
        );
    }

    /**
     * Test: Registrierungs-E-Mail wird gesendet
     * 
     * Simuliert den Registrierungsprozess und prüft die Willkommens-E-Mail.
     */
    public function testRegistrationEmailIsSent(): void
    {
        // Hier würde der eigentliche Service aufgerufen werden
        // $userService = new \App\Services\UserService(...);
        // $userService->registerUser('neu@test.de', 'Neuer User');
        
        // Für diesen Demo-Test simulieren wir das Senden
        $this->sendTestEmail(
            'neu@test.de',
            'Willkommen bei VAES',
            'Sehr geehrte(r) Neuer User, willkommen beim Vereins-Arbeitsstunden-Erfassungssystem.'
        );

        // Prüfen
        $this->assertTrue($this->mailhog->waitForMessages(1, 5));
        
        $messages = $this->mailhog->getMessagesByRecipient('neu@test.de');
        $this->assertCount(1, $messages, 'Genau eine E-Mail an den neuen User');
        
        $message = array_values($messages)[0];
        $this->assertTrue(
            $this->mailhog->messageContains($message, 'Willkommen'),
            'E-Mail sollte Willkommenstext enthalten'
        );
    }

    /**
     * Test: Prüfer erhält Benachrichtigung bei neuem Antrag
     */
    public function testReviewerNotificationOnSubmission(): void
    {
        // Simulieren: Mitglied reicht Antrag ein → Prüfer bekommt E-Mail
        $this->sendTestEmail(
            'pruefer@verein.de',
            'Neuer Antrag zur Prüfung: 2026-00001',
            'Ein neuer Arbeitsstunden-Antrag wurde eingereicht und wartet auf Ihre Prüfung.'
        );

        $this->assertTrue($this->mailhog->waitForMessages(1, 5));
        
        $messages = $this->mailhog->getMessagesBySubject('Neuer Antrag');
        $this->assertNotEmpty($messages, 'Prüfer sollte Benachrichtigung erhalten');
        
        $message = array_values($messages)[0];
        $this->assertTrue(
            $this->mailhog->messageContains($message, '2026-00001'),
            'E-Mail sollte Antragsnummer enthalten'
        );
    }

    /**
     * Test: Mitglied erhält Benachrichtigung bei Freigabe
     */
    public function testMemberNotificationOnApproval(): void
    {
        $this->sendTestEmail(
            'mitglied@test.de',
            'Ihr Antrag 2026-00001 wurde freigegeben',
            'Ihr Arbeitsstunden-Antrag wurde geprüft und freigegeben. 4,5 Stunden wurden Ihrem Konto gutgeschrieben.'
        );

        $this->assertTrue($this->mailhog->waitForMessages(1, 5));
        
        $messages = $this->mailhog->getMessagesByRecipient('mitglied@test.de');
        $this->assertNotEmpty($messages);
        
        $message = array_values($messages)[0];
        $this->assertTrue(
            $this->mailhog->messageContains($message, 'freigegeben'),
            'E-Mail sollte Freigabe-Bestätigung enthalten'
        );
        $this->assertTrue(
            $this->mailhog->messageContains($message, '4,5 Stunden'),
            'E-Mail sollte Stundenanzahl enthalten'
        );
    }

    /**
     * Test: Mitglied erhält Benachrichtigung bei Rückfrage
     */
    public function testMemberNotificationOnInquiry(): void
    {
        $this->sendTestEmail(
            'mitglied@test.de',
            'Rückfrage zu Ihrem Antrag 2026-00001',
            'Der Prüfer hat eine Rückfrage zu Ihrem Antrag: Bitte laden Sie einen Nachweis hoch.'
        );

        $this->assertTrue($this->mailhog->waitForMessages(1, 5));
        
        $message = $this->mailhog->getLatestMessage();
        $this->assertTrue(
            $this->mailhog->messageContains($message, 'Rückfrage'),
            'E-Mail sollte Rückfrage-Hinweis enthalten'
        );
    }

    /**
     * Test: Mehrere E-Mails in korrekter Reihenfolge
     */
    public function testMultipleEmailsInCorrectOrder(): void
    {
        // Drei E-Mails schnell hintereinander senden
        $this->sendTestEmail('user1@test.de', 'E-Mail 1', 'Erste E-Mail');
        usleep(100000); // 100ms
        $this->sendTestEmail('user2@test.de', 'E-Mail 2', 'Zweite E-Mail');
        usleep(100000);
        $this->sendTestEmail('user3@test.de', 'E-Mail 3', 'Dritte E-Mail');

        $this->assertTrue($this->mailhog->waitForMessages(3, 10));
        
        $messages = $this->mailhog->getMessages(10);
        $this->assertCount(3, $messages, 'Alle drei E-Mails sollten ankommen');
    }

    /**
     * Test: E-Mail enthält korrekte Links
     */
    public function testEmailContainsCorrectLinks(): void
    {
        $this->sendTestEmail(
            'mitglied@test.de',
            'Neuer Dialog zu Ihrem Antrag',
            '<html><body>
                <p>Sie haben eine neue Nachricht.</p>
                <a href="http://192.168.3.98/helferstunden/entries/view/123">Zum Antrag</a>
            </body></html>',
            true // HTML
        );

        $this->assertTrue($this->mailhog->waitForMessages(1, 5));
        
        $message = $this->mailhog->getLatestMessage();
        $links = $this->mailhog->extractLinks($message);
        
        $this->assertNotEmpty($links, 'E-Mail sollte Links enthalten');
        $this->assertStringContainsString(
            '/entries/view/123',
            implode(' ', $links),
            'E-Mail sollte Link zum Antrag enthalten'
        );
    }

    /**
     * Hilfsmethode: Sendet Test-E-Mail über PHPMailer an MailHog
     */
    private function sendTestEmail(
        string $to,
        string $subject,
        string $body,
        bool $isHtml = false
    ): void {
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        
        $mail->isSMTP();
        $mail->Host = getenv('MAIL_HOST') ?: 'localhost';
        $mail->Port = (int)(getenv('MAIL_PORT') ?: 1025);
        $mail->SMTPAuth = false;
        $mail->CharSet = 'UTF-8';
        
        $mail->setFrom('system@vaes.local', 'VAES System');
        $mail->addAddress($to);
        
        $mail->Subject = $subject;
        
        if ($isHtml) {
            $mail->isHTML(true);
            $mail->Body = $body;
            $mail->AltBody = strip_tags($body);
        } else {
            $mail->Body = $body;
        }
        
        $mail->send();
    }
}
