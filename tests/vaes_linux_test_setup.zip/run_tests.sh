#!/bin/bash
#
# VAES - Automatisierte Test-Ausführung
# Für Ubuntu Linux Webserver
#
# Verwendung:
#   ./run_tests.sh                    # Alle Tests
#   ./run_tests.sh --suite Unit       # Nur Unit-Tests
#   ./run_tests.sh --suite Integration # Nur Integration-Tests
#   ./run_tests.sh --filter Email     # Nur E-Mail-Tests
#   ./run_tests.sh --coverage         # Mit Code-Coverage-Report
#
# Voraussetzungen:
#   - PHP 8.1+ mit CLI
#   - Composer
#   - MailHog läuft auf localhost:1025 (SMTP) und localhost:8025 (API)
#

set -e

# ══════════════════════════════════════════════════════════════
# Konfiguration - HIER ANPASSEN!
# ══════════════════════════════════════════════════════════════

# Projektpfad
PROJECT_ROOT="/var/www/html/TSC-Helferstundenverwaltung"

# Kein separates src-Verzeichnis - App liegt direkt im Root
SRC_DIR="$PROJECT_ROOT"
TESTS_DIR="$PROJECT_ROOT/tests"

# MailHog
MAILHOG_API_URL="http://localhost:8025/api/v2"
MAILHOG_SMTP_PORT=1025

# Test-Datenbank (separate DB für Tests empfohlen!)
DB_HOST="localhost"
DB_NAME="vaes_test"
DB_USER="vaes_test"
DB_PASS="test_password"

# ══════════════════════════════════════════════════════════════
# Farben und Hilfsfunktionen
# ══════════════════════════════════════════════════════════════

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

success() { echo -e "${GREEN}✓ $1${NC}"; }
error() { echo -e "${RED}✗ $1${NC}"; }
info() { echo -e "${CYAN}→ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠ $1${NC}"; }

# ══════════════════════════════════════════════════════════════
# Parameter verarbeiten
# ══════════════════════════════════════════════════════════════

SUITE="All"
FILTER=""
COVERAGE=false
VERBOSE=false
SKIP_MAILHOG=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --suite|-s)
            SUITE="$2"
            shift 2
            ;;
        --filter|-f)
            FILTER="$2"
            shift 2
            ;;
        --coverage|-c)
            COVERAGE=true
            shift
            ;;
        --verbose|-v)
            VERBOSE=true
            shift
            ;;
        --skip-mailhog)
            SKIP_MAILHOG=true
            shift
            ;;
        --help|-h)
            echo "VAES Test-Runner"
            echo ""
            echo "Verwendung: $0 [Optionen]"
            echo ""
            echo "Optionen:"
            echo "  --suite, -s SUITE    Testsuite: Unit, Integration, Feature, All (default)"
            echo "  --filter, -f FILTER  Nur Tests die FILTER im Namen enthalten"
            echo "  --coverage, -c       Code-Coverage-Report generieren"
            echo "  --verbose, -v        Ausführliche Ausgabe"
            echo "  --skip-mailhog       MailHog-Check überspringen"
            echo "  --help, -h           Diese Hilfe anzeigen"
            echo ""
            echo "Beispiele:"
            echo "  $0                          # Alle Tests"
            echo "  $0 --suite Unit             # Nur Unit-Tests"
            echo "  $0 --filter Email           # Nur E-Mail-Tests"
            echo "  $0 --suite Integration -c   # Integration-Tests mit Coverage"
            exit 0
            ;;
        *)
            error "Unbekannte Option: $1"
            exit 1
            ;;
    esac
done

# ══════════════════════════════════════════════════════════════
# Header
# ══════════════════════════════════════════════════════════════

echo ""
echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║           VAES - Automatisierte Test-Ausführung              ║${NC}"
echo -e "${BLUE}║           Vereins-Arbeitsstunden-Erfassungssystem            ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# ══════════════════════════════════════════════════════════════
# 1. Voraussetzungen prüfen
# ══════════════════════════════════════════════════════════════

info "Prüfe Voraussetzungen..."

# PHP prüfen
if command -v php &> /dev/null; then
    PHP_VERSION=$(php -v | head -n 1 | grep -oP 'PHP \K[0-9]+\.[0-9]+')
    success "PHP $PHP_VERSION gefunden"
else
    error "PHP nicht gefunden!"
    exit 1
fi

# PHP-Version mindestens 8.1?
PHP_MAJOR=$(echo $PHP_VERSION | cut -d. -f1)
PHP_MINOR=$(echo $PHP_VERSION | cut -d. -f2)
if [[ $PHP_MAJOR -lt 8 ]] || [[ $PHP_MAJOR -eq 8 && $PHP_MINOR -lt 1 ]]; then
    error "PHP 8.1+ erforderlich, gefunden: $PHP_VERSION"
    exit 1
fi

# Composer prüfen
if command -v composer &> /dev/null; then
    COMPOSER_VERSION=$(composer --version --no-interaction 2>/dev/null | grep -oP 'Composer version \K[0-9]+\.[0-9]+')
    success "Composer $COMPOSER_VERSION gefunden"
else
    error "Composer nicht gefunden! Installation: https://getcomposer.org"
    exit 1
fi

# Projektverzeichnis prüfen
if [[ -d "$SRC_DIR" ]]; then
    success "Projektverzeichnis gefunden: $SRC_DIR"
else
    error "Projektverzeichnis nicht gefunden: $SRC_DIR"
    echo ""
    warn "Bitte PROJECT_ROOT in diesem Script anpassen!"
    warn "Aktuell: $PROJECT_ROOT"
    echo ""
    info "Mögliche Pfade finden:"
    info "  find /var/www -name 'composer.json' 2>/dev/null"
    info "Erwartet: /var/www/html/TSC-Helferstundenverwaltung"
    exit 1
fi

# ══════════════════════════════════════════════════════════════
# 2. MailHog prüfen
# ══════════════════════════════════════════════════════════════

if [[ "$SKIP_MAILHOG" == false ]]; then
    info "Prüfe MailHog-Verfügbarkeit..."
    
    # API prüfen
    if curl -s --connect-timeout 3 "$MAILHOG_API_URL/messages?limit=1" > /dev/null 2>&1; then
        success "MailHog API erreichbar: $MAILHOG_API_URL"
        
        # Anzahl E-Mails anzeigen
        MSG_COUNT=$(curl -s "$MAILHOG_API_URL/messages" | grep -oP '"total":\K[0-9]+' || echo "0")
        info "  → $MSG_COUNT E-Mail(s) in MailHog vorhanden"
    else
        warn "MailHog API nicht erreichbar: $MAILHOG_API_URL"
        warn "E-Mail-Tests werden möglicherweise fehlschlagen."
        echo ""
        info "MailHog starten:"
        info "  mailhog &"
        info "  # oder als Service:"
        info "  sudo systemctl start mailhog"
        echo ""
    fi
    
    # SMTP-Port prüfen
    if nc -z localhost $MAILHOG_SMTP_PORT 2>/dev/null; then
        success "MailHog SMTP erreichbar: localhost:$MAILHOG_SMTP_PORT"
    else
        warn "MailHog SMTP nicht erreichbar auf Port $MAILHOG_SMTP_PORT"
    fi
fi

# ══════════════════════════════════════════════════════════════
# 3. Dependencies installieren
# ══════════════════════════════════════════════════════════════

echo ""
info "Prüfe/Installiere Dependencies..."

cd "$SRC_DIR"

# Root-Warnung unterdrücken
export COMPOSER_ALLOW_SUPERUSER=1

if [[ ! -d "vendor" ]]; then
    info "Führe 'composer install' aus..."
    composer install --no-interaction --prefer-dist
else
    # Nur prüfen ob PHPUnit vorhanden
    if [[ ! -f "vendor/bin/phpunit" ]]; then
        info "PHPUnit fehlt, führe 'composer install' aus..."
        composer install --no-interaction --prefer-dist
    fi
fi

if [[ -f "vendor/bin/phpunit" ]]; then
    PHPUNIT_VERSION=$(vendor/bin/phpunit --version | grep -oP 'PHPUnit \K[0-9]+\.[0-9]+')
    success "PHPUnit $PHPUNIT_VERSION installiert"
else
    error "PHPUnit nicht gefunden! Prüfe composer.json"
    exit 1
fi

# ══════════════════════════════════════════════════════════════
# 4. phpunit.xml prüfen/erstellen
# ══════════════════════════════════════════════════════════════

echo ""
info "Prüfe PHPUnit-Konfiguration..."

PHPUNIT_CONFIG="$SRC_DIR/phpunit.xml"

if [[ ! -f "$PHPUNIT_CONFIG" ]]; then
    warn "phpunit.xml nicht gefunden, erstelle Standardkonfiguration..."
    
    cat > "$PHPUNIT_CONFIG" << 'PHPUNIT_XML'
<?xml version="1.0" encoding="UTF-8"?>
<phpunit xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:noNamespaceSchemaLocation="vendor/phpunit/phpunit/phpunit.xsd"
         bootstrap="vendor/autoload.php"
         colors="true"
         cacheDirectory=".phpunit.cache"
         executionOrder="depends,defects"
         beStrictAboutOutputDuringTests="true"
         failOnRisky="true"
         failOnWarning="true">

    <testsuites>
        <testsuite name="Unit">
            <directory>../tests/Unit</directory>
        </testsuite>
        <testsuite name="Integration">
            <directory>../tests/Integration</directory>
        </testsuite>
        <testsuite name="Feature">
            <directory>../tests/Feature</directory>
        </testsuite>
    </testsuites>

    <coverage>
        <report>
            <html outputDirectory="../tests/coverage-report"/>
            <text outputFile="php://stdout" showOnlySummary="true"/>
        </report>
        <include>
            <directory suffix=".php">app</directory>
        </include>
        <exclude>
            <directory>app/Views</directory>
        </exclude>
    </coverage>

    <php>
        <env name="APP_ENV" value="testing"/>
        <env name="APP_DEBUG" value="true"/>
        
        <!-- MailHog -->
        <env name="MAIL_HOST" value="localhost"/>
        <env name="MAIL_PORT" value="1025"/>
        <env name="MAIL_USERNAME" value=""/>
        <env name="MAIL_PASSWORD" value=""/>
        <env name="MAIL_ENCRYPTION" value=""/>
        <env name="MAIL_FROM_ADDRESS" value="test@vaes.local"/>
        <env name="MAIL_FROM_NAME" value="VAES Test"/>
        <env name="MAILHOG_API_URL" value="http://localhost:8025/api/v2"/>
        
        <!-- Test-Datenbank -->
        <env name="DB_HOST" value="localhost"/>
        <env name="DB_DATABASE" value="vaes_test"/>
        <env name="DB_USERNAME" value="vaes_test"/>
        <env name="DB_PASSWORD" value="test_password"/>
    </php>

</phpunit>
PHPUNIT_XML
    
    success "phpunit.xml erstellt"
else
    success "phpunit.xml vorhanden"
fi

# ══════════════════════════════════════════════════════════════
# 5. Test-Verzeichnisstruktur prüfen
# ══════════════════════════════════════════════════════════════

echo ""
info "Prüfe Test-Verzeichnisstruktur..."

mkdir -p "$TESTS_DIR/Unit"
mkdir -p "$TESTS_DIR/Integration"
mkdir -p "$TESTS_DIR/Feature"
mkdir -p "$TESTS_DIR/Support"

# Zähle Tests
TEST_COUNT=$(find "$TESTS_DIR" -name "*Test.php" 2>/dev/null | wc -l)
success "$TEST_COUNT Test-Datei(en) gefunden"

# ══════════════════════════════════════════════════════════════
# 6. Tests ausführen
# ══════════════════════════════════════════════════════════════

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    Starte Test-Ausführung                    ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

cd "$SRC_DIR"

# PHPUnit-Argumente aufbauen
PHPUNIT_ARGS=""

# Testsuite
if [[ "$SUITE" != "All" ]]; then
    PHPUNIT_ARGS="$PHPUNIT_ARGS --testsuite $SUITE"
fi

# Filter
if [[ -n "$FILTER" ]]; then
    PHPUNIT_ARGS="$PHPUNIT_ARGS --filter $FILTER"
fi

# Coverage
if [[ "$COVERAGE" == true ]]; then
    PHPUNIT_ARGS="$PHPUNIT_ARGS --coverage-html ../tests/coverage-report"
    info "Code-Coverage wird generiert in: $TESTS_DIR/coverage-report"
    
    # Xdebug prüfen
    if ! php -m | grep -q xdebug; then
        warn "Xdebug nicht aktiv - Coverage benötigt Xdebug oder PCOV"
        info "Installation: sudo apt install php-xdebug"
    fi
fi

# Verbose
if [[ "$VERBOSE" == true ]]; then
    PHPUNIT_ARGS="$PHPUNIT_ARGS -v"
fi

info "Führe aus: vendor/bin/phpunit $PHPUNIT_ARGS"
echo ""

START_TIME=$(date +%s)

# PHPUnit ausführen
set +e  # Fehler nicht abbrechen
vendor/bin/phpunit $PHPUNIT_ARGS
EXIT_CODE=$?
set -e

END_TIME=$(date +%s)
DURATION=$((END_TIME - START_TIME))

# ══════════════════════════════════════════════════════════════
# 7. Ergebnis
# ══════════════════════════════════════════════════════════════

echo ""
echo -e "${BLUE}══════════════════════════════════════════════════════════════${NC}"

if [[ $EXIT_CODE -eq 0 ]]; then
    success "Alle Tests bestanden! (Dauer: ${DURATION}s)"
else
    error "Tests fehlgeschlagen! Exit-Code: $EXIT_CODE"
fi

# Coverage-Report Hinweis
if [[ "$COVERAGE" == true ]] && [[ -f "$TESTS_DIR/coverage-report/index.html" ]]; then
    echo ""
    info "Coverage-Report: file://$TESTS_DIR/coverage-report/index.html"
    info "Oder im Browser: http://192.168.3.98/helferstunden/tests/coverage-report/"
fi

# MailHog-Hinweis
if [[ "$SKIP_MAILHOG" == false ]]; then
    echo ""
    info "MailHog Web-UI: http://192.168.3.98:8025"
    info "Dort können Sie die während der Tests gesendeten E-Mails einsehen."
fi

echo ""
exit $EXIT_CODE
