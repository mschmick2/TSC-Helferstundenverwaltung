#!/bin/bash
#
# MailHog Installation und Setup für Ubuntu
# 
# Dieses Script installiert MailHog und richtet es als Systemdienst ein.
#

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

success() { echo -e "${GREEN}✓ $1${NC}"; }
error() { echo -e "${RED}✗ $1${NC}"; }
info() { echo -e "${CYAN}→ $1${NC}"; }

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║           MailHog Installation für VAES                      ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Root-Check
if [[ $EUID -ne 0 ]]; then
   error "Dieses Script muss als root ausgeführt werden!"
   info "Verwendung: sudo $0"
   exit 1
fi

# ══════════════════════════════════════════════════════════════
# 1. MailHog herunterladen
# ══════════════════════════════════════════════════════════════

info "Lade MailHog herunter..."

MAILHOG_VERSION="v1.0.1"
MAILHOG_URL="https://github.com/mailhog/MailHog/releases/download/${MAILHOG_VERSION}/MailHog_linux_amd64"

if [[ -f /usr/local/bin/mailhog ]]; then
    success "MailHog bereits installiert"
else
    wget -q "$MAILHOG_URL" -O /usr/local/bin/mailhog
    chmod +x /usr/local/bin/mailhog
    success "MailHog installiert nach /usr/local/bin/mailhog"
fi

# ══════════════════════════════════════════════════════════════
# 2. Systemd Service erstellen
# ══════════════════════════════════════════════════════════════

info "Erstelle Systemd-Service..."

cat > /etc/systemd/system/mailhog.service << 'SERVICE'
[Unit]
Description=MailHog Email Testing
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/mailhog -smtp-bind-addr 0.0.0.0:1025 -api-bind-addr 0.0.0.0:8025 -ui-bind-addr 0.0.0.0:8025
Restart=on-failure
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=mailhog

# Sicherheit
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
SERVICE

success "Service-Datei erstellt: /etc/systemd/system/mailhog.service"

# ══════════════════════════════════════════════════════════════
# 3. Service aktivieren und starten
# ══════════════════════════════════════════════════════════════

info "Aktiviere und starte MailHog-Service..."

systemctl daemon-reload
systemctl enable mailhog
systemctl start mailhog

sleep 2

if systemctl is-active --quiet mailhog; then
    success "MailHog-Service läuft!"
else
    error "MailHog-Service konnte nicht gestartet werden"
    journalctl -u mailhog --no-pager -n 20
    exit 1
fi

# ══════════════════════════════════════════════════════════════
# 4. Firewall-Regeln (optional)
# ══════════════════════════════════════════════════════════════

info "Prüfe Firewall..."

if command -v ufw &> /dev/null; then
    if ufw status | grep -q "active"; then
        info "UFW aktiv - füge Regeln hinzu..."
        ufw allow 8025/tcp comment "MailHog Web UI"
        # SMTP nur lokal, nicht von außen
        # ufw allow 1025/tcp comment "MailHog SMTP"
        success "Firewall-Regel für Port 8025 hinzugefügt"
    fi
fi

# ══════════════════════════════════════════════════════════════
# 5. Verbindungstest
# ══════════════════════════════════════════════════════════════

echo ""
info "Teste Verbindung..."

# API Test
if curl -s http://localhost:8025/api/v2/messages > /dev/null 2>&1; then
    success "MailHog API erreichbar: http://localhost:8025"
else
    error "MailHog API nicht erreichbar!"
fi

# SMTP Test
if nc -z localhost 1025 2>/dev/null; then
    success "MailHog SMTP erreichbar: localhost:1025"
else
    error "MailHog SMTP nicht erreichbar!"
fi

# ══════════════════════════════════════════════════════════════
# 6. Zusammenfassung
# ══════════════════════════════════════════════════════════════

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    Installation abgeschlossen                 ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "MailHog ist jetzt eingerichtet:"
echo ""
echo "  Web-UI:     http://192.168.3.98:8025"
echo "  SMTP:       localhost:1025 (kein Auth, keine Verschlüsselung)"
echo "  API:        http://localhost:8025/api/v2"
echo ""
echo "Service-Befehle:"
echo "  sudo systemctl status mailhog   # Status anzeigen"
echo "  sudo systemctl restart mailhog  # Neustarten"
echo "  sudo systemctl stop mailhog     # Stoppen"
echo "  journalctl -u mailhog -f        # Logs verfolgen"
echo ""
echo "PHP-Konfiguration für VAES (in config.php):"
echo ""
echo "  'mail' => ["
echo "      'host' => 'localhost',"
echo "      'port' => 1025,"
echo "      'username' => '',"
echo "      'password' => '',"
echo "      'encryption' => '',"
echo "  ]"
echo ""
